
import './App.css';
import Tictactoe from './Components/TicTacToe/Tictactoe';

function App() {
  return (
    <div>
      <Tictactoe/>
    </div>
  );
}

export default App;
